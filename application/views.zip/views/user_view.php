<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>User View</title>
</head>
<body>

<?php

foreach ($results as $object)
 {
	echo $object->username."<br>";
}
// echo "$results";
?>




</body>
</html>